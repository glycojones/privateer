from . import pvt_core as pvt
import pandas as pd
import gemmi
import re
import os

from chimerax.core.commands import CmdDesc

def validate_glycans_xray(structurefile:str, mtzfile:str, F_column_name:str, SIGF_column_name:str, outputdir:str):
    structurefilename = os.path.basename(structurefile)
    column_labels = f"{F_column_name},{SIGF_column_name}"
    glycosylation = pvt.GlycosylationComposition(structurefile, mtzfile, column_labels)
    number_of_glycans = glycosylation.get_number_of_glycan_chains_detected()
    AllSugars = []
    for n in range(number_of_glycans):
        glycan = glycosylation.get_glycan(n)
        numsugars = glycan.get_total_number_of_sugars()
        glycosylation_type = glycan.get_glycosylation_type()
        wurcs = glycan.get_wurcs_notation()
        root_info = glycan.get_root_info()
        chain_id = glycan.get_root_sugar_chain_id()
        torsion_summary = glycan.get_torsions_collection()
        linkages = {}
        for torsion in torsion_summary:
            acceptors = re.findall(r'\d+', torsion["acceptor_atom"])
            donors = re.findall(r'\d+', torsion["donor_atom"])
            
            if acceptors and donors:
                linkage = torsion["second_residue"] + "-" + acceptors[-1] + "," + donors[-1]  + "-" +  torsion["first_residue"]
            else:
                if not acceptors: 
                    linkage = torsion["second_residue"] + "-" + torsion["acceptor_atom"] + "," + donors[-1]  + "-" +  torsion["first_residue"]
                
                if not donors:
                    linkage = torsion["second_residue"] + "-" + acceptors[-1] + "," + torsion["donor_atom"]  + "-" +  torsion["first_residue"]

            formatted_torsion = {
                "firstResidue": torsion["first_residue"],
                "secondResidue": torsion["second_residue"],
                "donorAtom": torsion["donor_atom"],
                "acceptorAtom": torsion["acceptor_atom"],
                "firstSeqId": torsion["first_seqid"],
                "secondSeqId": torsion["second_seqid"],
                "phi": torsion["phi"],
                "psi": torsion["psi"]
            }
            linkages.setdefault(linkage, []).append(formatted_torsion)

        snfg_data = glycan.get_SNFG_strings()
        snfg = snfg_data["SNFG"]
        sugars= []
        for j in range(numsugars):
            sugar = glycan.get_monosaccharide(j)

            summary = sugar.get_sugar_summary()

            sugar_id = f'{summary["sugar_name_short"]}-{summary["sugar_pdb_chain"]}-{summary["sugar_seqnum"]}'
            Q = summary["Q"]
            Phi = summary["Phi"]
            Theta = summary["Theta"]
            RSCC = summary["RSCC"]
            detected_type = sugar.get_denomination()
            conformation = sugar.get_conformation_name()
            mFo = summary["mFo"]
            BFactor = sugar.get_bfactor()
            diagnostic = sugar.get_privateer_diagnostic()

            sugar_data = {
                "sugarId": sugar_id, 
                "q": Q,
                "phi": Phi, 
                "theta": Theta, 
                "rscc": RSCC,
                "detectedType": detected_type,
                "conformation": conformation, 
                "bFactor": BFactor,
                "mFo": mFo,
                "diagnostic": diagnostic
            }
            sugars.append(sugar_data)
            AllSugars.append(sugar_data)
        root_info_format = {
            "proteinResidueType": root_info["ProteinResidueType"],
            "proteinResidueId": root_info["ProteinResidueID"],
            "proteinResidueSeqnum": root_info["ProteinResidueSeqnum"],
            "proteinChainId": root_info["ProteinChainID"],
            "rootSugarChainId": root_info["RootSugarChainID"]
        }
        glycan_data = {
            **root_info_format, 
            "numberOfSugars": numsugars,
            "wurcs": wurcs, 
            "snfg": snfg, 
            "sugars": sugars,
            "linkages": linkages
        }
    df = pd.DataFrame.from_dict(AllSugars)
    csv_out = os.path.join(outputdir,f"{structurefilename}-privateer-report.csv")
    df.to_csv(csv_out)
    return df

def hello_world(session):
    # All command functions are invoked with ``session`` as its
    # first argument.  Useful session attributes include:
    #   logger: chimerax.core.logger.Logger instance
    #   models: chimerax.core.models.Models instance
    session.logger.info("Hello world!")

# CmdDesc contains the command description.  For the
# "hello" command, we expect no arguments.
hello_world_desc = CmdDesc()